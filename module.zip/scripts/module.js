var be = Object.defineProperty;
var ee = (t) => {
  throw TypeError(t);
};
var ke = (t, e, n) => e in t ? be(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var A = (t, e, n) => ke(t, typeof e != "symbol" ? e + "" : e, n), Ue = (t, e, n) => e.has(t) || ee("Cannot " + n);
var te = (t, e, n) => e.has(t) ? ee("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n);
var N = (t, e, n) => (Ue(t, e, "access private method"), n);
const d = "ttrpg-survival-system", Ie = [
  {
    key: "supplyDetail",
    scope: "world",
    type: "String",
    default: "abstract",
    config: !0,
    choices: { abstract: "Abstract (day counts)", ledger: "Ledger (real inventory)" }
  },
  { key: "trackedNeeds", scope: "world", type: "Object", default: { food: !0, water: !0, firewood: !0 }, config: !1 },
  {
    key: "upkeepPrompt",
    scope: "world",
    type: "String",
    default: "onlyWhenWrong",
    config: !0,
    choices: { always: "Always show", onlyWhenWrong: "Only when something's wrong" }
  },
  {
    key: "sourceMode",
    scope: "world",
    type: "String",
    default: "communalFirst",
    config: !0,
    choices: { communalFirst: "Communal first", personalFirst: "Personal first" }
  },
  {
    key: "climateModel",
    scope: "world",
    type: "String",
    default: "manual",
    config: !0,
    choices: { off: "Off", manual: "Manual band", auto: "Read weather module (later)" }
  },
  {
    key: "lethalDeprivation",
    scope: "world",
    type: "String",
    default: "capStage3",
    config: !0,
    choices: { capStage3: "Cap at stage 3", climbToDeath: "Climb to death" }
  },
  {
    key: "splitPartyMode",
    scope: "world",
    type: "String",
    default: "single",
    config: !0,
    choices: { single: "Single party", named: "Named groups" }
  },
  { key: "foraging", scope: "world", type: "Boolean", default: !1, config: !0 },
  { key: "forageDC", scope: "world", type: "Number", default: 15, config: !0 },
  { key: "nextWaterDays", scope: "world", type: "Number", default: 0, config: !0 },
  { key: "hotMeal", scope: "world", type: "Boolean", default: !1, config: !0 },
  { key: "hotMealEffectUuid", scope: "world", type: "String", default: "", config: !0 },
  { key: "maxCatchUpDays", scope: "world", type: "Number", default: 14, config: !0 },
  { key: "mountDefaultApplyConsequences", scope: "world", type: "Boolean", default: !1, config: !0 },
  {
    key: "hudDensity",
    scope: "client",
    type: "String",
    default: "full",
    config: !0,
    choices: { full: "Full", compact: "Compact" }
  },
  // Internal bookkeeping (not shown in the config UI).
  { key: "caravanDocUuid", scope: "world", type: "String", default: "", config: !1 },
  { key: "lastTickDay", scope: "world", type: "Number", default: 0, config: !1 },
  { key: "dataVersion", scope: "world", type: "Number", default: 1, config: !1 }
];
function Ae() {
  const t = { String, Number, Boolean, Object };
  for (const e of Ie)
    game.settings.register(d, e.key, {
      scope: e.scope,
      config: e.config,
      type: t[e.type],
      default: e.default,
      ...e.choices ? { choices: e.choices } : {},
      name: `SURVIVAL.Settings.${e.key}.name`,
      hint: `SURVIVAL.Settings.${e.key}.hint`
    });
}
class Pe {
  constructor(e) {
    A(this, "counts", /* @__PURE__ */ new Map());
    for (const n of e) this.counts.set(n.id, { ...n.counts });
  }
  available(e, n) {
    var o;
    return ((o = this.counts.get(e)) == null ? void 0 : o[n]) ?? 0;
  }
  totalAvailable(e, n) {
    let o = 0;
    for (const s of e) o += this.available(s, n);
    return o;
  }
  /** Draw up to `need` of `kind`, walking `orderedPoolIds` and decrementing as it goes.
   *  Returns the amount actually drawn (≤ need). */
  draw(e, n, o) {
    let s = o;
    for (const i of e) {
      if (s <= 0) break;
      const r = this.counts.get(i);
      if (!r) continue;
      const a = Math.min(r[n], s);
      a > 0 && (r[n] -= a, s -= a);
    }
    return o - s;
  }
  /** Draw `kind` (food/water) first, then top up any shortfall from the shared `provision`
   *  reserve along the same order. Provision decrements as it's spent, so food and water (and
   *  every consumer) share one fungible pool — the transactional invariant still holds. */
  drawWithProvision(e, n, o) {
    const s = this.draw(e, n, o);
    let i = o - s;
    for (const r of e) {
      if (i <= 0) break;
      const a = this.counts.get(r);
      if (!a || a.provision <= 0) continue;
      const u = Math.min(a.provision, i);
      a.provision -= u, i -= u;
    }
    return o - i;
  }
  /** Current counts per pool (to write back to the registry after the day commits). */
  snapshot() {
    const e = {};
    for (const [n, o] of this.counts) e[n] = { ...o };
    return e;
  }
}
const Ve = {
  temperate: { waterMult: 1, cold: !1, bundles: 0, thirstGracePenalty: 0, coldStagePerNight: 0 },
  hot: { waterMult: 2, cold: !1, bundles: 0, thirstGracePenalty: 0, coldStagePerNight: 0 },
  extremeHeat: { waterMult: 3, cold: !1, bundles: 0, thirstGracePenalty: 1, coldStagePerNight: 0 },
  cold: { waterMult: 1, cold: !0, bundles: 1, thirstGracePenalty: 0, coldStagePerNight: 0 },
  extremeCold: { waterMult: 1, cold: !0, bundles: 2, thirstGracePenalty: 0, coldStagePerNight: 1 }
};
function J(t) {
  return Ve[t];
}
const H = {
  // S1 first day past grace, S2 +2, S3 +2, S4 +3 (terminal).
  hunger: { offsets: [1, 3, 5, 8], blockHealingAtStage3: !0 },
  // Faster: S1 +1, S2 +1, S3 +1, S4 +2.
  thirst: { offsets: [1, 2, 3, 5], blockHealingAtStage3: !0 },
  // Same cadence as thirst, but suppressed entirely while warm.
  cold: { offsets: [1, 2, 3, 5], blockHealingAtStage3: !1 }
};
function Ce(t) {
  return t === "climbToDeath" ? 4 : 3;
}
function De(t, e) {
  let n = 0;
  for (const o of e) t >= o && n++;
  return n;
}
function G(t, e, n, o, s, i = 0) {
  if (n) {
    t.daysDeprived = 0, t.stage = Math.max(0, t.stage - 1), t.blockedHealing = !1;
    return;
  }
  t.daysDeprived += 1 + Math.max(0, i);
  const r = t.daysDeprived - o, a = De(r, e.offsets);
  t.stage = Math.min(Ce(s), Math.max(t.stage, a)), t.blockedHealing = e.blockHealingAtStage3 && t.stage >= 3;
}
function Re(t) {
  const e = [], n = [];
  for (const o of t)
    o.isMount ? e.push(o.id) : o.isStorage && n.push(o.id);
  return { mountIds: e, storageIds: n, present: t };
}
function E(t) {
  const e = /* @__PURE__ */ new Set(), n = [];
  for (const o of t)
    o && !e.has(o) && (e.add(o), n.push(o));
  return n;
}
function $e(t, e, n) {
  if (t.isMount)
    return E([t.poolId, ...e.storageIds]);
  const o = [...e.mountIds, ...e.storageIds];
  return E(n === "communalFirst" ? [...o, t.poolId] : [t.poolId, ...o]);
}
function ne(t, e, n) {
  return n.some(
    (s) => s.withParty[e] !== !0 && s.counts[t] > 0
  ) ? "separated" : "out";
}
function W() {
  return { daysDeprived: 0, stage: 0, blockedHealing: !1 };
}
function F() {
  return { hunger: W(), thirst: W(), cold: W() };
}
const ue = {
  sourceMode: "communalFirst",
  lethal: "capStage3",
  maxCatchUpDays: 14
};
function oe(t, e, n, o) {
  let s = 0;
  for (const i of t) {
    if (i.group !== e || !i.enabled || !i.needsConsumption) continue;
    const r = i.ration[n] * i.sizeMult;
    s += n === "water" ? r * o : r;
  }
  return s;
}
function Le(t, e) {
  const n = J(t.climate[e] ?? "temperate"), o = t.pools.filter((u) => u.withParty[e] === !0), s = (u) => o.reduce((l, c) => l + c.counts[u], 0), i = oe(t.consumers, e, "food", n.waterMult), r = oe(t.consumers, e, "water", n.waterMult), a = o.reduce((u, l) => u + l.counts.provision, 0);
  return {
    food: i > 0 ? Math.floor((s("food") + a) / i) : 0,
    water: r > 0 ? Math.floor((s("water") + a) / r) : 0,
    firewood: n.bundles > 0 ? Math.floor(s("firewood") / n.bundles) : 0
  };
}
function Ne(t, e, n, o) {
  var y, M;
  const s = J(t.climate[e] ?? "temperate"), i = t.pools.filter((f) => f.withParty[e] === !0), r = Re(i), a = new Pe(i), u = t.consumers.filter(
    (f) => f.group === e && f.enabled && f.needsConsumption
  ), l = [], c = [], g = /* @__PURE__ */ new Map();
  for (const f of u) {
    if (f.ration.food === 0 && f.ration.water === 0) continue;
    const h = f.ration.food * f.sizeMult, p = f.ration.water * f.sizeMult * s.waterMult, I = $e(f, r, o.sourceMode), C = a.drawWithProvision(I, "food", h), D = a.drawWithProvision(I, "water", p);
    l.push({
      consumerId: f.id,
      name: f.name,
      food: { need: h, got: C },
      water: { need: p, got: D },
      warm: !1
    }), g.set(f.id, { food: C >= h, water: D >= p });
    const L = f.isMount && !f.applyConsequences;
    C < h && c.push({
      consumerId: f.id,
      name: f.name,
      kind: "food",
      missing: h - C,
      cause: ne("food", e, t.pools),
      isMountNarrateOnly: L
    }), D < p && c.push({
      consumerId: f.id,
      name: f.name,
      kind: "water",
      missing: p - D,
      cause: ne("water", e, t.pools),
      isMountNarrateOnly: L
    });
  }
  let m = !1, v = 0;
  if (s.bundles > 0) {
    const f = [...r.mountIds, ...r.storageIds];
    a.totalAvailable(f, "firewood") >= s.bundles && (a.draw(f, "firewood", s.bundles), m = !0, v = s.bundles);
  }
  for (const f of u) {
    if (f.isMount && !f.applyConsequences || f.ration.food === 0 && f.ration.water === 0) continue;
    const h = g.get(f.id) ?? { food: !0, water: !0 }, p = (y = t.actorState)[M = f.id] ?? (y[M] = F()), I = f.warmAuto || f.keptWarm || m, C = !s.cold || I;
    G(p.hunger, H.hunger, h.food, f.graceDays.hunger, o.lethal);
    const D = Math.max(0, f.graceDays.thirst - s.thirstGracePenalty);
    G(p.thirst, H.thirst, h.water, D, o.lethal), G(p.cold, H.cold, C, f.graceDays.cold, o.lethal, s.cold ? s.coldStagePerNight : 0);
    const L = l.find((Me) => Me.consumerId === f.id);
    L && (L.warm = I);
  }
  const U = a.snapshot();
  for (const f of i) U[f.id] && (f.counts = U[f.id]);
  return { day: n, group: e, band: t.climate[e] ?? "temperate", draws: l, shortfalls: c, firewoodBurned: v, campfireLit: m };
}
function O(t, e, n = {}) {
  const o = { ...ue, ...n }, s = t.lastTickDay;
  if (e <= s)
    return t.lastTickDay = e, {
      fromDay: s,
      toDay: e,
      daysProcessed: 0,
      overflow: !1,
      perDay: [],
      lastDayShortfalls: [],
      headlineByGroup: se(t),
      state: t
    };
  const r = e - s > o.maxCatchUpDays, a = r ? s + o.maxCatchUpDays : e, u = [];
  for (let g = s + 1; g <= a; g++) {
    for (const m of t.groups)
      u.push(Ne(t, m, g, o));
    t.lastTickDay = g;
  }
  t.lastTickDay = e;
  const l = a, c = u.filter((g) => g.day === l).flatMap((g) => g.shortfalls);
  return {
    fromDay: s,
    toDay: e,
    daysProcessed: a - s,
    overflow: r,
    perDay: u,
    lastDayShortfalls: c,
    headlineByGroup: se(t),
    state: t
  };
}
function se(t) {
  const e = {};
  for (const n of t.groups) e[n] = Le(t, n);
  return e;
}
const xe = ["critFail", "fail", "success", "critSuccess"];
function Te(t, e, n) {
  let o = t >= n + 10 ? 3 : t >= n ? 2 : t <= n - 10 ? 0 : 1;
  return e === 20 ? o = Math.min(3, o + 1) : e === 1 && (o = Math.max(0, o - 1)), xe[o];
}
function ze(t) {
  switch (t) {
    case "critSuccess":
      return { food: 2, fatigued: !1 };
    case "success":
      return { food: 1, fatigued: !1 };
    case "fail":
      return { food: 0, fatigued: !0 };
    case "critFail":
      return { food: 0, fatigued: !0 };
  }
}
const Fe = ["hunger", "thirst", "cold"];
function Oe(t, e, n) {
  const o = J(t.climate[e] ?? "temperate"), s = t.pools.map((r) => {
    const a = r.withParty[e] === !0;
    return {
      id: r.id,
      label: r.label,
      counts: { ...r.counts },
      withParty: a,
      separated: !a,
      isMount: r.isMount,
      isStorage: r.isStorage
    };
  }), i = t.consumers.filter((r) => r.group === e).map((r) => {
    const a = t.actorState[r.id], u = {};
    let l = 0;
    for (const c of Fe) {
      const g = (a == null ? void 0 : a[c]) ?? { daysDeprived: 0, stage: 0, blockedHealing: !1 };
      l = Math.max(l, g.stage), u[c] = {
        stage: g.stage,
        daysDeprived: g.daysDeprived,
        grace: r.graceDays[c],
        statusKey: g.stage >= 1 ? `SURVIVAL.Status.${c}.${Math.min(g.stage, 3)}` : null,
        blockedHealing: g.blockedHealing
      };
    }
    return {
      id: r.id,
      name: r.name,
      sizeMult: r.sizeMult,
      isMount: r.isMount,
      zeroNeeds: r.ration.food === 0 && r.ration.water === 0,
      tracks: u,
      worstStage: l
    };
  });
  return {
    group: e,
    climate: t.climate[e] ?? "temperate",
    headline: n,
    waterMult: o.waterMult,
    coldActive: o.cold,
    firewoodNeeded: o.bundles > 0,
    pools: s,
    roster: i
  };
}
function He(t, e) {
  return t.groups.map(
    (n) => Oe(t, n, e[n] ?? { food: 0, water: 0, firewood: 0 })
  );
}
const ce = 1;
function de() {
  return {
    dataVersion: ce,
    groups: ["Main"],
    climate: { Main: "temperate" },
    members: [],
    pools: []
  };
}
function Ge(t) {
  return { food: (t == null ? void 0 : t.food) ?? 0, water: (t == null ? void 0 : t.water) ?? 0, firewood: (t == null ? void 0 : t.firewood) ?? 0, provision: (t == null ? void 0 : t.provision) ?? 0 };
}
function Ee(t) {
  var r;
  const e = de();
  if (!t) return e;
  const n = t.groups && t.groups.length > 0 ? [...t.groups] : ["Main"], o = {};
  for (const a of n) o[a] = ((r = t.climate) == null ? void 0 : r[a]) ?? "temperate";
  const s = (t.pools ?? []).map((a) => ({
    id: a.id,
    label: a.label ?? a.id,
    counts: Ge(a.counts),
    withParty: { ...a.withParty ?? {} },
    isMount: !!a.isMount,
    isStorage: !!a.isStorage,
    ...a.actorUuid ? { actorUuid: a.actorUuid } : {}
  })), i = (t.members ?? []).map((a) => ({
    uuid: a.uuid,
    group: a.group ?? "Main",
    enabled: a.enabled ?? !0,
    isMount: !!a.isMount,
    applyConsequences: !!a.applyConsequences,
    poolId: a.poolId ?? null,
    ...a.needsOverride ? { needsOverride: a.needsOverride } : {}
  }));
  return { dataVersion: t.dataVersion ?? ce, groups: n, climate: o, members: i, pools: s };
}
const q = "registry";
class S {
  constructor(e) {
    this.doc = e;
  }
  static async findOrCreate() {
    const e = game.settings.get(d, "caravanDocUuid");
    let n = e ? await fromUuid(e) : null;
    return n || (n = await JournalEntry.create({
      name: "Survival Caravan",
      ownership: { default: 0 },
      // GM-only
      flags: { [d]: { [q]: de() } }
    }), await game.settings.set(d, "caravanDocUuid", n.uuid)), new S(n);
  }
  load() {
    return Ee(this.doc.getFlag(d, q));
  }
  async save(e) {
    await this.doc.setFlag(d, q, e);
  }
  get uuid() {
    return this.doc.uuid;
  }
}
function We(t, e, n, o) {
  const s = t.members.filter((a) => e[a.uuid] !== void 0).map((a) => {
    var l, c;
    const u = e[a.uuid];
    return {
      id: a.uuid,
      name: u.name,
      group: a.group,
      sizeMult: u.sizeMult,
      ration: {
        food: ((l = a.needsOverride) == null ? void 0 : l.food) ?? u.ration.food,
        water: ((c = a.needsOverride) == null ? void 0 : c.water) ?? u.ration.water
      },
      graceDays: u.graceDays,
      isMount: a.isMount,
      applyConsequences: a.applyConsequences,
      enabled: a.enabled,
      needsConsumption: u.needsConsumption,
      poolId: a.poolId,
      keptWarm: u.keptWarm,
      warmAuto: u.warmAuto
    };
  }), i = t.pools.map((a) => ({ ...a, counts: { ...a.counts }, withParty: { ...a.withParty } })), r = {
    groups: [...t.groups],
    climate: { ...t.climate },
    consumers: s,
    pools: i,
    actorState: {},
    lastTickDay: o
  };
  for (const a of s)
    r.actorState[a.id] = n[a.id] ? _e(n[a.id]) : F();
  return r;
}
function qe(t, e) {
  const n = new Map(e.pools.map((o) => [o.id, o]));
  for (const o of t.pools) {
    const s = n.get(o.id);
    s && (o.counts = { ...s.counts });
  }
}
function _e(t) {
  return {
    hunger: { ...t.hunger },
    thirst: { ...t.thirst },
    cold: { ...t.cold }
  };
}
function Be() {
  return {
    sourceMode: game.settings.get(d, "sourceMode"),
    lethal: game.settings.get(d, "lethalDeprivation"),
    maxCatchUpDays: game.settings.get(d, "maxCatchUpDays")
  };
}
function Ke(t, e) {
  var o;
  const n = {};
  for (const s of t.members) {
    const i = fromUuidSync(s.uuid);
    i && (n[s.uuid] = {
      name: i.name ?? s.uuid,
      sizeMult: e.getSizeMult(i),
      ration: e.getCreatureRation(i),
      graceDays: {
        hunger: e.getGraceDays(i, "hunger"),
        thirst: e.getGraceDays(i, "thirst"),
        cold: e.getGraceDays(i, "cold")
      },
      needsConsumption: e.needsConsumption(i),
      warmAuto: e.isWarmSourceEquipped(i),
      keptWarm: !!((o = i.getFlag) != null && o.call(i, d, "warmth"))
    });
  }
  return n;
}
function je(t) {
  var n;
  const e = {};
  for (const o of t.members) {
    const s = fromUuidSync(o.uuid);
    e[o.uuid] = ((n = s == null ? void 0 : s.getFlag) == null ? void 0 : n.call(s, d, "state")) ?? F();
  }
  return e;
}
async function Ye(t) {
  for (const e of t.consumers) {
    const n = fromUuidSync(e.id);
    n != null && n.setFlag && await n.setFlag(d, "state", t.actorState[e.id]);
  }
}
async function K(t, e) {
  var u;
  const { registry: n, reg: o, state: s } = await fe(e), i = new Map(s.pools.map((l) => [l.id, { ...l.counts }])), r = O(s, t, Be());
  if (X())
    for (const l of s.pools) {
      const c = (u = o.pools.find((v) => v.id === l.id)) == null ? void 0 : u.actorUuid, g = c ? fromUuidSync(c) : null;
      if (!g) continue;
      const m = i.get(l.id);
      for (const v of ["food", "water", "firewood", "provision"]) {
        const U = m[v] - l.counts[v];
        U > 0 && await e.consume(g, v, U);
      }
    }
  else
    qe(o, s), await n.save(o);
  await game.settings.set(d, "lastTickDay", s.lastTickDay), await Ye(s), await Xe(s, e);
  const a = game.settings.get(d, "nextWaterDays") ?? 0;
  return a > 0 && await game.settings.set(d, "nextWaterDays", Math.max(0, a - r.daysProcessed)), r;
}
async function Qe(t, e = "Main") {
  if (!t.applyHotMeal) return 0;
  const n = await S.findOrCreate(), o = n.load(), s = o.pools.find((r) => r.withParty[e] === !0 && r.counts.firewood > 0);
  if (!s) return -1;
  s.counts.firewood -= 1, await n.save(o);
  let i = 0;
  for (const r of o.members) {
    if (r.group !== e || !r.enabled || r.isMount) continue;
    const a = fromUuidSync(r.uuid);
    a && (await t.applyHotMeal(a), i++);
  }
  return i;
}
async function Je(t, e) {
  const n = fromUuidSync(t);
  if (!n || !e.rollForage) return null;
  const o = game.settings.get(d, "forageDC") ?? 15, s = await e.rollForage(n, o);
  if (!s) return null;
  const { food: i, fatigued: r } = ze(s);
  if (i > 0) {
    const a = await S.findOrCreate(), u = a.load(), l = u.members.find((m) => m.uuid === t), c = (l == null ? void 0 : l.group) ?? "Main", g = u.pools.find((m) => (m.isStorage || m.isMount) && m.withParty[c] === !0) ?? u.pools.find((m) => m.id === (l == null ? void 0 : l.poolId));
    g && (g.counts.food += i, await a.save(u));
  }
  return { degree: s, food: i, fatigued: r };
}
async function Xe(t, e) {
  for (const n of t.consumers) {
    if (n.isMount && !n.applyConsequences) continue;
    const o = t.actorState[n.id];
    if (!o) continue;
    const s = fromUuidSync(n.id);
    s && await e.reconcileConsequences(s, {
      hunger: o.hunger.stage,
      thirst: o.thirst.stage,
      cold: o.cold.stage
    });
  }
}
function X() {
  return game.settings.get(d, "supplyDetail") === "ledger";
}
async function fe(t) {
  var a;
  const e = await S.findOrCreate(), n = e.load(), o = Ke(n, t), s = je(n), i = game.settings.get(d, "lastTickDay") ?? 0, r = We(n, o, s, i);
  if (X())
    for (const u of r.pools) {
      const l = (a = n.pools.find((g) => g.id === u.id)) == null ? void 0 : a.actorUuid, c = l ? fromUuidSync(l) : null;
      c && (u.counts = {
        food: t.getAvailable(c, "food"),
        water: t.getAvailable(c, "water"),
        firewood: t.getAvailable(c, "firewood"),
        provision: t.getAvailable(c, "provision")
      });
    }
  for (const u of r.pools) {
    const l = n.pools.find((m) => m.id === u.id), c = l != null && l.actorUuid ? fromUuidSync(l.actorUuid) : null, g = game.i18n.localize(u.isStorage ? "SURVIVAL.Pool.sharedStock" : "SURVIVAL.Pool.personalPack");
    c != null && c.name ? u.label = `${c.name} (${g})` : u.isStorage && (u.label = `${u.label} (${g})`);
  }
  return { registry: e, reg: n, state: r };
}
async function ge(t) {
  return (await fe(t)).state;
}
async function Ze(t, e = "Main") {
  const n = await ge(t);
  return O(n, n.lastTickDay).headlineByGroup[e];
}
async function Z(t) {
  const e = await ge(t), n = O(e, e.lastTickDay).headlineByGroup;
  return He(e, n);
}
async function et(t, e, n) {
  const o = await S.findOrCreate(), s = o.load(), i = s.pools.find((r) => r.id === t);
  i && (i.withParty[e] = n, await o.save(s));
}
async function tt(t, e, n, o) {
  const s = await S.findOrCreate(), i = s.load(), r = i.pools.find((u) => u.id === t);
  if (!r) return;
  const a = Math.max(0, Math.round(n));
  if (X() && o && r.actorUuid) {
    const u = fromUuidSync(r.actorUuid);
    if (u) {
      const l = o.getAvailable(u, e);
      a > l ? await o.grant(u, e, a - l) : a < l && await o.consume(u, e, l - a);
    }
  } else
    r.counts[e] = a, await s.save(i);
}
async function nt(t, e) {
  const n = await S.findOrCreate(), o = n.load();
  o.climate[t] = e, await n.save(o);
}
async function ot(t, e) {
  const n = await S.findOrCreate(), o = n.load();
  for (const s of o.pools) s.withParty[t] = !1;
  o.climate[t] = "temperate", await n.save(o);
}
async function st(t, e) {
  const n = game.settings.get(d, "lastTickDay") ?? 0;
  return K(n + t, e);
}
async function at(t, e = {}) {
  const n = await S.findOrCreate(), o = n.load();
  if (o.members.some((a) => a.uuid === t)) return;
  const s = e.group ?? "Main", i = !!e.isMount, r = i ? `mount-${t}` : `pack-${t}`;
  o.members.push({ uuid: t, group: s, enabled: !0, isMount: i, applyConsequences: !1, poolId: r }), o.pools.some((a) => a.id === r) || o.pools.push({
    id: r,
    label: i ? "Mount supply" : "Personal pack",
    counts: { food: 0, water: 0, firewood: 0, provision: 0 },
    withParty: { [s]: !0 },
    isMount: i,
    isStorage: i,
    actorUuid: t
  }), await n.save(o);
}
async function it(t, e) {
  const o = (await S.findOrCreate()).load();
  let s = 0;
  for (const i of o.members) {
    if (i.group !== e) continue;
    const r = fromUuidSync(i.uuid);
    r && (await t.reconcileConsequences(r, { hunger: 0, thirst: 0, cold: 0 }), r.setFlag && await r.setFlag(d, "state", F()), s++);
  }
  return s;
}
async function rt(t, e) {
  var a;
  const n = await S.findOrCreate(), o = n.load(), s = o.members.find((u) => u.uuid === t);
  if (!s) return;
  s.isMount = e;
  let i = o.pools.find((u) => u.actorUuid === t) ?? (s.poolId ? o.pools.find((u) => u.id === s.poolId) : void 0);
  if (!i && e) {
    const u = s.poolId ?? `mount-${t}`;
    i = {
      id: u,
      label: "Mount supply",
      counts: { food: 0, water: 0, firewood: 0, provision: 0 },
      withParty: { [s.group]: !0 },
      isMount: !0,
      isStorage: !0,
      actorUuid: t
    }, o.pools.push(i), s.poolId = u;
  }
  i && (i.isMount = e, i.isStorage = e);
  const r = fromUuidSync(t);
  await ((a = r == null ? void 0 : r.setFlag) == null ? void 0 : a.call(r, d, "isMount", e)), await n.save(o);
}
async function lt(t, e = "Main") {
  const n = await S.findOrCreate(), o = n.load();
  o.pools.push({
    id: `base-${foundry.utils.randomID()}`,
    label: t || "Base",
    counts: { food: 0, water: 0, firewood: 0, provision: 0 },
    withParty: { [e]: !0 },
    isMount: !1,
    isStorage: !0
  }), await n.save(o);
}
async function ut(t, e) {
  const n = fromUuidSync(t);
  n != null && n.setFlag && await n.setFlag(d, "warmth", e);
}
async function me() {
  var n, o;
  const t = ((n = canvas == null ? void 0 : canvas.tokens) == null ? void 0 : n.controlled) ?? [];
  let e = 0;
  for (const s of t) {
    const i = s.actor;
    i != null && i.uuid && (await at(i.uuid, { isMount: !!((o = i.getFlag) != null && o.call(i, d, "isMount")) }), e++);
  }
  return e;
}
const ct = ["hunger", "thirst", "cold"];
function dt(t, e) {
  const n = t.perDay.filter((l) => l.group === e), o = { food: 0, water: 0, firewood: 0 };
  for (const l of n) {
    for (const c of l.draws)
      o.food += c.food.got, o.water += c.water.got;
    o.firewood += l.firewoodBurned;
  }
  const s = n.length > 0 && n.every((l) => l.shortfalls.length === 0), i = n.reduce((l, c) => Math.max(l, c.day), t.fromDay), r = /* @__PURE__ */ new Set(), a = [];
  for (const l of n)
    if (l.day === i)
      for (const c of l.shortfalls) {
        const g = `${c.consumerId}:${c.kind}`;
        r.has(g) || (r.add(g), a.push({
          actorUuid: c.consumerId,
          name: c.name,
          kind: c.kind,
          cause: c.cause,
          isMountNarrateOnly: c.isMountNarrateOnly
        }));
      }
  const u = [];
  for (const l of t.state.consumers) {
    if (l.group !== e) continue;
    const c = t.state.actorState[l.id];
    if (c)
      for (const g of ct) {
        const m = c[g].stage;
        m >= 1 && u.push({
          actorUuid: l.id,
          name: l.name,
          track: g,
          stage: m,
          statusKey: `SURVIVAL.Status.${g}.${Math.min(m, 3)}`
        });
      }
  }
  return {
    group: e,
    daysProcessed: t.daysProcessed,
    overflow: t.overflow,
    allGreen: s,
    consumed: o,
    shortfalls: a,
    clocks: u
  };
}
const x = { food: "🍖", water: "💧", firewood: "🔥" }, b = (t, e) => e ? game.i18n.format(t, e) : game.i18n.localize(t);
async function pe(t, e = "Main") {
  const n = dt(t, e), o = game.settings.get(d, "upkeepPrompt");
  if (n.allGreen && o === "onlyWhenWrong") {
    await ae(`<p class="ss-card-green">${b("SURVIVAL.Card.Green", { days: n.daysProcessed })}</p>`);
    return;
  }
  await ae(ft(n)), await gt(n);
}
function ft(t) {
  const e = [`<div class="ss-card"><h3>${b("SURVIVAL.Card.Title", { days: t.daysProcessed })}</h3>`];
  if (e.push(
    `<p class="ss-card-consumed">${x.food} ${t.consumed.food} · ${x.water} ${t.consumed.water} · ${x.firewood} ${t.consumed.firewood}</p>`
  ), t.overflow && e.push(`<p class="ss-card-warn">${b("SURVIVAL.Card.Overflow")}</p>`), t.shortfalls.length) {
    e.push(`<div class="ss-card-short"><b>${b("SURVIVAL.Card.WentWithout")}</b><ul>`);
    for (const n of t.shortfalls) {
      const o = b(n.cause === "separated" ? "SURVIVAL.Shortfall.separatedShort" : "SURVIVAL.Shortfall.outShort"), s = n.isMountNarrateOnly ? ` <em>(${b("SURVIVAL.Card.Narrate")})</em>` : "";
      e.push(`<li>${x[n.kind]} <b>${n.name}</b> — ${o}${s}</li>`);
    }
    e.push("</ul></div>");
  }
  if (t.clocks.length) {
    e.push(`<div class="ss-card-clocks"><b>${b("SURVIVAL.Card.Clocks")}</b><ul>`);
    for (const n of t.clocks) e.push(`<li><b>${n.name}</b> — ${b(n.statusKey)}</li>`);
    e.push("</ul></div>");
  }
  return e.push("</div>"), e.join("");
}
async function ae(t) {
  await ChatMessage.create({
    content: t,
    whisper: ChatMessage.getWhisperRecipients("GM"),
    speaker: { alias: b("SURVIVAL.Panel.Title") }
  });
}
async function gt(t) {
  const e = /* @__PURE__ */ new Map();
  for (const n of t.shortfalls) {
    if (n.isMountNarrateOnly) continue;
    const o = fromUuidSync(n.actorUuid);
    if (!o) continue;
    const s = (game.users ?? []).filter((i) => {
      var r;
      return !i.isGM && ((r = o.testUserPermission) == null ? void 0 : r.call(o, i, "OWNER"));
    });
    for (const i of s) {
      const r = e.get(i.id) ?? { user: i, lines: [] };
      r.lines.push(`${x[n.kind]} <b>${n.name}</b> — ${b(`SURVIVAL.Resource.${n.kind}`)}`), e.set(i.id, r);
    }
  }
  for (const { user: n, lines: o } of e.values())
    await ChatMessage.create({
      content: `<div class="ss-card"><p>${b("SURVIVAL.Card.NudgeIntro")}</p><ul class="ss-card-short">${o.map((s) => `<li>${s}</li>`).join("")}</ul></div>`,
      whisper: [n.id],
      speaker: { alias: b("SURVIVAL.Panel.Title") }
    });
}
const mt = ["temperate", "hot", "extremeHeat", "cold", "extremeCold"];
let k;
function pt(t) {
  k = t;
}
async function yt(t, e) {
  const n = Number(e.dataset.days ?? "1");
  if (k) {
    const o = await st(n, k);
    await pe(o);
  }
  this.render();
}
async function ht(t, e) {
  await et(e.dataset.pool, "Main", e.dataset.with === "true"), this.render();
}
async function wt() {
  await ot("Main"), this.render();
}
async function vt(t, e) {
  await nt("Main", e.dataset.band), this.render();
}
async function St(t, e) {
  const n = await Pt(Number(e.dataset.current ?? "0"));
  n !== null && (await tt(
    e.dataset.pool,
    e.dataset.kind,
    n,
    k
  ), this.render());
}
async function Mt() {
  var e;
  const t = await me();
  (e = ui.notifications) == null || e.info(game.i18n.format("SURVIVAL.Panel.Added", { n: t })), this.render();
}
async function bt(t, e) {
  await rt(e.dataset.actor, e.dataset.mount === "true"), this.render();
}
async function kt() {
  const t = await Vt(game.i18n.localize("SURVIVAL.Panel.BaseNameDefault"));
  t !== null && (await lt(t), this.render());
}
async function Ut() {
  var n;
  if (!k || !await foundry.applications.api.DialogV2.confirm({
    window: { title: game.i18n.localize("SURVIVAL.Panel.Reset") },
    content: `<p>${game.i18n.localize("SURVIVAL.Panel.ResetConfirm")}</p>`
  }).catch(() => !1)) return;
  const e = await it(k, "Main");
  (n = ui.notifications) == null || n.info(game.i18n.format("SURVIVAL.Panel.ResetDone", { n: e })), this.render();
}
async function It() {
  var e, n;
  if (!k) return;
  const t = await Qe(k, "Main");
  t === -1 ? (e = ui.notifications) == null || e.warn(game.i18n.localize("SURVIVAL.HotMeal.NoWood")) : t === 0 ? (n = ui.notifications) == null || n.warn(game.i18n.localize("SURVIVAL.HotMeal.CantCook")) : await ChatMessage.create({
    content: `<p>${game.i18n.format("SURVIVAL.HotMeal.Cooked", { n: t })}</p>`,
    speaker: { alias: game.i18n.localize("SURVIVAL.Panel.Title") }
  }), this.render();
}
async function At(t, e) {
  var s;
  if (!k) return;
  const n = await Je(e.dataset.actor, k);
  if (!n) {
    (s = ui.notifications) == null || s.warn(game.i18n.localize("SURVIVAL.Forage.CantRoll"));
    return;
  }
  const o = n.fatigued ? ` <em>${game.i18n.localize("SURVIVAL.Forage.Fatigued")}</em>` : "";
  await ChatMessage.create({
    content: `<p>${game.i18n.format("SURVIVAL.Forage.Result", { name: e.dataset.name ?? "", food: n.food })}${o}</p>`,
    speaker: { alias: game.i18n.localize("SURVIVAL.Panel.Title") }
  }), this.render();
}
async function Pt(t) {
  try {
    const e = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("SURVIVAL.Panel.EditPool") },
      content: `<input type="number" name="value" value="${t}" step="1" min="0" autofocus style="width:100%">`,
      ok: {
        label: game.i18n.localize("SURVIVAL.Panel.Set"),
        callback: (n, o) => Number(o.form.elements.value.value)
      }
    });
    return typeof e == "number" && !Number.isNaN(e) ? e : null;
  } catch {
    return null;
  }
}
async function Vt(t) {
  try {
    const e = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("SURVIVAL.Panel.BaseName") },
      content: `<input type="text" name="value" value="${t}" autofocus style="width:100%">`,
      ok: {
        label: game.i18n.localize("SURVIVAL.Panel.Set"),
        callback: (n, o) => String(o.form.elements.value.value ?? "").trim()
      }
    });
    return typeof e == "string" ? e : null;
  } catch {
    return null;
  }
}
function _(t) {
  return {
    label: t.statusKey ? game.i18n.localize(t.statusKey) : "—",
    clock: `${t.daysDeprived}/${t.grace}`,
    cls: t.stage >= 3 ? "danger" : t.stage >= 1 ? "warn" : ""
  };
}
const { ApplicationV2: Ct, HandlebarsApplicationMixin: Dt } = foundry.applications.api;
class j extends Dt(Ct) {
  async _prepareContext() {
    const n = (k ? await Z(k) : [])[0];
    return n ? {
      hasData: !0,
      climate: n.climate,
      waterMult: n.waterMult,
      firewoodNeeded: n.firewoodNeeded,
      headline: n.headline,
      foragingOn: game.settings.get(d, "foraging") === !0,
      hotMealOn: game.settings.get(d, "hotMeal") === !0,
      nextWaterDays: game.settings.get(d, "nextWaterDays") ?? 0,
      bands: mt.map((o) => ({
        band: o,
        active: o === n.climate,
        label: game.i18n.localize(`SURVIVAL.Band.${o}`)
      })),
      pools: n.pools.map((o) => ({
        id: o.id,
        label: o.label,
        isMount: o.isMount,
        separated: o.separated,
        withNext: (!o.withParty).toString(),
        food: o.counts.food,
        water: o.counts.water,
        firewood: o.counts.firewood,
        provision: o.counts.provision
      })),
      roster: n.roster.map((o) => ({
        id: o.id,
        name: o.name,
        size: o.isMount ? `Huge ×${o.sizeMult}` : o.sizeMult > 1 ? `×${o.sizeMult}` : "×1",
        isMount: o.isMount,
        roleNext: (!o.isMount).toString(),
        zeroNeeds: o.zeroNeeds,
        hunger: _(o.tracks.hunger),
        thirst: _(o.tracks.thirst),
        cold: _(o.tracks.cold)
      }))
    } : { hasData: !1 };
  }
}
A(j, "DEFAULT_OPTIONS", {
  id: `${d}-gm`,
  classes: [d, "ss-gm"],
  tag: "div",
  window: { title: "SURVIVAL.Panel.Title", icon: "fa-solid fa-campground", resizable: !0 },
  position: { width: 580 },
  actions: {
    advance: yt,
    toggleParty: ht,
    delving: wt,
    setClimate: vt,
    editPool: St,
    addSelected: Mt,
    addBase: kt,
    setRole: bt,
    reset: Ut,
    forage: At,
    cook: It
  }
}), A(j, "PARTS", {
  main: { template: `modules/${d}/templates/gm-panel.hbs` }
});
let R;
function ye() {
  R ?? (R = new j()), R.render({ force: !0 });
}
function Rt() {
  R != null && R.rendered && R.render();
}
let z;
function $t() {
  z = socketlib.registerModule(d), z.register("setWarm", (t, e) => ut(t, e));
}
async function Lt(t, e) {
  var n;
  if (z)
    try {
      await z.executeAsGM("setWarm", t, e);
    } catch (o) {
      (n = ui.notifications) == null || n.warn(game.i18n.localize("SURVIVAL.NoGM")), console.warn(`${d} | setWarm failed`, o);
    }
}
let Y;
function Nt(t) {
  Y = t;
}
async function xt(t, e) {
  await Lt(e.dataset.actor, e.dataset.warm === "true"), this.render();
}
function Tt(t) {
  let e = 0, n = null;
  for (const o of ["hunger", "thirst", "cold"]) {
    const s = t.tracks[o];
    s.stage > e && (e = s.stage, n = s.statusKey);
  }
  return e === 0 || !n ? { label: game.i18n.localize("SURVIVAL.Hud.Ok"), cls: "ok" } : { label: game.i18n.localize(n), cls: e >= 3 ? "danger" : "warn" };
}
const { ApplicationV2: zt, HandlebarsApplicationMixin: Ft } = foundry.applications.api;
class Q extends Ft(zt) {
  async _prepareContext() {
    const n = (Y ? await Z(Y) : [])[0];
    return n ? {
      hasData: !0,
      headline: n.headline,
      coldActive: n.coldActive,
      roster: n.roster.filter((o) => !o.zeroNeeds).map((o) => {
        var r, a;
        const s = fromUuidSync(o.id), i = !!((r = s == null ? void 0 : s.getFlag) != null && r.call(s, d, "warmth"));
        return {
          id: o.id,
          name: o.name,
          owned: (s == null ? void 0 : s.isOwner) === !0 && !((a = game.user) != null && a.isGM),
          warm: i,
          warmNext: (!i).toString(),
          status: Tt(o)
        };
      })
    } : { hasData: !1 };
  }
}
A(Q, "DEFAULT_OPTIONS", {
  id: `${d}-hud`,
  classes: [d, "ss-hud"],
  tag: "div",
  window: { title: "SURVIVAL.Panel.Title", icon: "fa-solid fa-heart-pulse", resizable: !1 },
  position: { width: 320 },
  actions: { toggleWarm: xt }
}), A(Q, "PARTS", {
  main: { template: `modules/${d}/templates/party-hud.hbs` }
});
let $;
function he() {
  $ ?? ($ = new Q()), $.render({ force: !0 });
}
function Ot() {
  $ != null && $.rendered && $.render();
}
const Ht = ["auto", "food", "water", "provision", "firewood", "none"];
function Gt() {
  Hooks.on("renderItemSheetV2", ie), Hooks.on("renderItemSheet", ie);
}
function Et(t) {
  return ["consumable", "equipment", "weapon", "armor", "treasure", "backpack"].includes(t == null ? void 0 : t.type);
}
function ie(t, e) {
  var n;
  try {
    const o = (t == null ? void 0 : t.document) ?? (t == null ? void 0 : t.object);
    if (!o || !Et(o)) return;
    const s = e instanceof HTMLElement ? e : (e == null ? void 0 : e[0]) ?? (t == null ? void 0 : t.element) ?? null;
    if (!(s != null && s.querySelector) || s.querySelector(".ss-resource-field")) return;
    const i = ((n = o.getFlag) == null ? void 0 : n.call(o, d, "resource")) ?? "auto", r = document.createElement("div");
    r.className = "ss-resource-field", r.style.cssText = "display:flex;gap:6px;align-items:center;padding:4px 8px;font-size:12px;";
    const a = document.createElement("label");
    a.textContent = game.i18n.localize("SURVIVAL.Item.Resource");
    const u = document.createElement("select");
    u.style.flex = "1";
    for (const l of Ht) {
      const c = document.createElement("option");
      c.value = l, c.textContent = game.i18n.localize(`SURVIVAL.Item.${l}`), l === i && (c.selected = !0), u.appendChild(c);
    }
    u.addEventListener("change", async () => {
      var l, c;
      u.value === "auto" ? await ((l = o.unsetFlag) == null ? void 0 : l.call(o, d, "resource")) : await ((c = o.setFlag) == null ? void 0 : c.call(o, d, "resource", u.value));
    }), r.append(a, u), (s.querySelector(".window-content") ?? s).appendChild(r);
  } catch (o) {
    console.warn(`${d} | item sheet injection failed`, o);
  }
}
class Wt {
  constructor() {
    A(this, "systemId", "generic");
  }
  getResourceLots() {
    return [];
  }
  getAvailable() {
    return 0;
  }
  async consume() {
    return 0;
  }
  async grant() {
  }
  getCreatureRation() {
    return { food: 1, water: 1 };
  }
  getGraceDays() {
    return 1;
  }
  getSizeMult(e) {
    var o, s, i;
    const n = (i = (s = (o = e == null ? void 0 : e.system) == null ? void 0 : o.traits) == null ? void 0 : s.size) == null ? void 0 : i.value;
    return n === "huge" || n === "grg" || n === "gargantuan" ? 4 : n === "lg" || n === "large" ? 2 : 1;
  }
  isMount(e) {
    var n;
    return !!((n = e == null ? void 0 : e.getFlag) != null && n.call(e, d, "isMount"));
  }
  needsConsumption(e) {
    var o, s, i;
    const n = (i = (s = (o = e == null ? void 0 : e.system) == null ? void 0 : o.attributes) == null ? void 0 : s.hp) == null ? void 0 : i.value;
    return n === void 0 || n > 0;
  }
  async reconcileConsequences() {
  }
  isWarmSourceEquipped() {
    return !1;
  }
  async rollForage() {
    return null;
  }
}
function we(t) {
  return Math.max(0, t.quantity * t.daysPerUnit - t.daysUsed);
}
function qt(t) {
  return t.reduce((e, n) => e + we(n), 0);
}
function _t(t, e) {
  let n = Math.max(0, Math.floor(e));
  const o = [];
  for (const s of t) {
    if (n <= 0) break;
    const i = we(s);
    if (i <= 0) continue;
    const r = Math.min(i, n);
    n -= r;
    const a = s.daysUsed + r, u = Math.floor(a / s.daysPerUnit), l = s.quantity - u, c = a - u * s.daysPerUnit;
    o.push({
      itemId: s.itemId,
      newQuantity: Math.max(0, l),
      newDaysUsed: l <= 0 ? 0 : c,
      delete: l <= 0
    });
  }
  return { drawn: Math.floor(e) - n, changes: o };
}
const Bt = {
  hunger: {
    1: [{ slug: "fatigued" }],
    2: [{ slug: "fatigued" }, { slug: "enfeebled", value: 1 }],
    3: [{ slug: "fatigued" }, { slug: "drained", value: 1 }],
    4: [{ slug: "fatigued" }, { slug: "drained", value: 2 }, { slug: "doomed", value: 1 }]
  },
  thirst: {
    1: [{ slug: "fatigued" }],
    2: [{ slug: "fatigued" }, { slug: "sickened", value: 1 }],
    3: [{ slug: "fatigued" }, { slug: "drained", value: 1 }],
    4: [{ slug: "fatigued" }, { slug: "drained", value: 2 }, { slug: "doomed", value: 1 }]
  },
  cold: {
    1: [{ slug: "fatigued" }],
    2: [{ slug: "fatigued" }, { slug: "clumsy", value: 1 }],
    3: [{ slug: "fatigued" }, { slug: "clumsy", value: 2 }, { slug: "drained", value: 1 }],
    4: [{ slug: "fatigued" }, { slug: "drained", value: 2 }, { slug: "doomed", value: 1 }]
  }
};
function B(t, e) {
  return e >= 1 ? Bt[t][Math.min(e, 4)] ?? [] : [];
}
function Kt(t) {
  const e = /* @__PURE__ */ new Map();
  for (const n of t)
    e.has(n.slug) ? n.value !== void 0 && e.set(n.slug, Math.max(e.get(n.slug) ?? 0, n.value)) : e.set(n.slug, n.value);
  return [...e.entries()].map(([n, o]) => o === void 0 ? { slug: n } : { slug: n, value: o });
}
function jt(t) {
  return Kt([
    ...B("hunger", t.hunger),
    ...B("thirst", t.thirst),
    ...B("cold", t.cold)
  ]);
}
const V = {
  food: "survival-ration-day",
  water: "survival-water-day",
  firewood: "survival-firewood-bundle",
  provision: "survival-provision-day"
}, ve = {
  food: "Ration (day)",
  water: "Water (day)",
  firewood: "Firewood (bundle)",
  provision: "Provisions (day)"
};
function re(t, e) {
  return {
    name: ve[t],
    type: "consumable",
    system: {
      slug: V[t],
      quantity: e,
      category: "other",
      description: { value: "" },
      traits: { value: [], rarity: "common" }
    }
  };
}
function Yt(t) {
  var s, i;
  const e = (s = t.getFlag) == null ? void 0 : s.call(t, d, "resource");
  if (e === "none") return null;
  const n = t.slug ?? ((i = t.system) == null ? void 0 : i.slug) ?? "";
  if (e === "food" || e === "water" || e === "firewood" || e === "provision")
    return { kind: e, daysPerUnit: n === "rations" ? 7 : 1 };
  if (n === V.food) return { kind: "food", daysPerUnit: 1 };
  if (n === V.water) return { kind: "water", daysPerUnit: 1 };
  if (n === V.firewood) return { kind: "firewood", daysPerUnit: 1 };
  if (n === V.provision) return { kind: "provision", daysPerUnit: 1 };
  if (n === "rations") return { kind: "provision", daysPerUnit: 7 };
  const o = String(t.name ?? "").toLowerCase();
  return /water|waterskin|canteen|flask/.test(o) ? { kind: "water", daysPerUnit: 1 } : /firewood|kindling|\bfuel\b|\blogs?\b/.test(o) ? { kind: "firewood", daysPerUnit: 1 } : /ration|provision|trail\s?mix|foodstuff/.test(o) ? { kind: "provision", daysPerUnit: 1 } : null;
}
var P, T, Se;
class Qt {
  constructor() {
    te(this, P);
    A(this, "systemId", "pf2e");
  }
  getResourceLots(e, n) {
    return N(this, P, T).call(this, e, n).map((o) => ({
      kind: n,
      available: Math.max(0, o.quantity * o.daysPerUnit - o.daysUsed),
      itemId: o.itemId,
      label: ve[n]
    }));
  }
  getAvailable(e, n) {
    return qt(N(this, P, T).call(this, e, n));
  }
  async consume(e, n, o) {
    var a, u;
    const s = _t(N(this, P, T).call(this, e, n), o), i = s.changes.filter((l) => !l.delete).map((l) => ({ _id: l.itemId, "system.quantity": l.newQuantity, [`flags.${d}.daysUsed`]: l.newDaysUsed })), r = s.changes.filter((l) => l.delete).map((l) => l.itemId);
    return i.length && await ((a = e.updateEmbeddedDocuments) == null ? void 0 : a.call(e, "Item", i)), r.length && await ((u = e.deleteEmbeddedDocuments) == null ? void 0 : u.call(e, "Item", r)), s.drawn;
  }
  async grant(e, n, o) {
    var i, r, a, u, l;
    if (o <= 0) return;
    const s = (r = (i = (e == null ? void 0 : e.items) ?? []).find) == null ? void 0 : r.call(i, (c) => {
      var g;
      return (c.slug ?? ((g = c.system) == null ? void 0 : g.slug)) === V[n];
    });
    if (s) {
      const c = s.quantity ?? ((a = s.system) == null ? void 0 : a.quantity) ?? 0;
      await ((u = e.updateEmbeddedDocuments) == null ? void 0 : u.call(e, "Item", [{ _id: s.id, "system.quantity": c + o }]));
    } else
      await ((l = e.createEmbeddedDocuments) == null ? void 0 : l.call(e, "Item", [re(n, o)]));
  }
  // --- Creature inspection (pure; testable with mock actors) ---
  getCreatureRation() {
    return { food: 1, water: 1 };
  }
  getGraceDays(e, n) {
    var s, i, r;
    const o = ((r = (i = (s = e == null ? void 0 : e.system) == null ? void 0 : s.abilities) == null ? void 0 : i.con) == null ? void 0 : r.mod) ?? 0;
    return Math.max(0, o + 1);
  }
  getSizeMult(e) {
    var o, s, i;
    const n = (i = (s = (o = e == null ? void 0 : e.system) == null ? void 0 : o.traits) == null ? void 0 : s.size) == null ? void 0 : i.value;
    return n === "huge" || n === "grg" ? 4 : n === "lg" ? 2 : 1;
  }
  isMount(e) {
    var n;
    return !!((n = e == null ? void 0 : e.getFlag) != null && n.call(e, d, "isMount"));
  }
  needsConsumption(e) {
    var o, s, i;
    const n = (i = (s = (o = e == null ? void 0 : e.system) == null ? void 0 : o.attributes) == null ? void 0 : s.hp) == null ? void 0 : i.value;
    return !(typeof n == "number" && n <= 0);
  }
  isWarmSourceEquipped(e) {
    var o, s, i;
    const n = (e == null ? void 0 : e.items) ?? [];
    for (const r of n)
      if ((r.slug ?? ((o = r.system) == null ? void 0 : o.slug)) === "cold-weather-clothing") {
        const u = (i = (s = r.system) == null ? void 0 : s.equipped) == null ? void 0 : i.carryType;
        if (u === void 0 || u === "worn") return !0;
      }
    return !1;
  }
  // --- Consequences (Foundry; smoke-tested in a live world) ---
  async reconcileConsequences(e, n) {
    var r, a, u, l, c, g, m, v, U;
    const o = jt(n), s = ((r = e.getFlag) == null ? void 0 : r.call(e, d, "applied")) ?? [], i = [];
    for (const y of s) {
      const M = o.some((h) => h.slug === y.slug), f = (u = (a = e.items) == null ? void 0 : a.get) == null ? void 0 : u.call(a, y.itemId);
      !M && f && await ((l = e.deleteEmbeddedDocuments) == null ? void 0 : l.call(e, "Item", [y.itemId]));
    }
    for (const y of o) {
      const M = s.find((f) => {
        var h, p;
        return f.slug === y.slug && ((p = (h = e.items) == null ? void 0 : h.get) == null ? void 0 : p.call(h, f.itemId));
      });
      if (M)
        y.value !== void 0 && M.value !== y.value && await ((m = (g = (c = game.pf2e) == null ? void 0 : c.ConditionManager) == null ? void 0 : g.updateConditionValue) == null ? void 0 : m.call(g, M.itemId, e, y.value)), i.push({ slug: y.slug, itemId: M.itemId, value: y.value });
      else {
        const f = await ((v = e.increaseCondition) == null ? void 0 : v.call(
          e,
          y.slug,
          y.value !== void 0 ? { value: y.value } : void 0
        ));
        f != null && f.id && i.push({ slug: y.slug, itemId: f.id, value: y.value });
      }
    }
    await ((U = e.setFlag) == null ? void 0 : U.call(e, d, "applied", i));
  }
  async rollForage(e, n) {
    var r, a, u, l, c;
    const o = (r = e == null ? void 0 : e.getStatistic) == null ? void 0 : r.call(e, "survival");
    if (!(o != null && o.roll)) return null;
    const s = await o.roll({ dc: n, action: "subsist", label: "Subsist (Survival)" });
    if (!s) return null;
    const i = ((c = (l = (u = (a = s.dice) == null ? void 0 : a[0]) == null ? void 0 : u.results) == null ? void 0 : l[0]) == null ? void 0 : c.result) ?? 10;
    return Te(s.total, i, n);
  }
  async applyHotMeal(e) {
    var a, u, l, c, g, m, v, U, y, M, f, h;
    const n = ((u = (a = e.items ?? []).filter) == null ? void 0 : u.call(a, (p) => {
      var I;
      return (p.slug ?? ((I = p.system) == null ? void 0 : I.slug)) === "hot-meal";
    })) ?? [];
    n.length && await ((l = e.deleteEmbeddedDocuments) == null ? void 0 : l.call(e, "Item", n.map((p) => p.id)));
    const o = game.settings.get(d, "hotMealEffectUuid");
    let s = null;
    if (o) {
      const p = await fromUuid(o);
      s = ((c = p == null ? void 0 : p.toObject) == null ? void 0 : c.call(p)) ?? null;
    }
    s ?? (s = N(this, P, Se).call(this)), await ((g = e.createEmbeddedDocuments) == null ? void 0 : g.call(e, "Item", [s]));
    const i = e.level ?? ((U = (v = (m = e.system) == null ? void 0 : m.details) == null ? void 0 : v.level) == null ? void 0 : U.value) ?? 1, r = ((f = (M = (y = e.system) == null ? void 0 : y.attributes) == null ? void 0 : M.hp) == null ? void 0 : f.temp) ?? 0;
    i > r && await ((h = e.update) == null ? void 0 : h.call(e, { "system.attributes.hp.temp": i }));
  }
  async seedSupplies() {
    var e, n, o;
    for (const s of ["food", "water", "firewood"])
      ((n = (e = game.items ?? []).some) == null ? void 0 : n.call(e, (r) => {
        var a;
        return (r.slug ?? ((a = r.system) == null ? void 0 : a.slug)) === V[s];
      })) || await ((o = Item.create) == null ? void 0 : o.call(Item, re(s, 1)));
  }
}
P = new WeakSet(), // --- Ledger inventory (v2 / M8) ---
T = function(e, n) {
  var s, i, r, a, u;
  const o = [];
  for (const l of (e == null ? void 0 : e.items) ?? []) {
    if (!((s = l == null ? void 0 : l.isOfType) != null && s.call(l, "physical")) && !((i = l == null ? void 0 : l.system) != null && i.quantity) && ((r = l == null ? void 0 : l.system) == null ? void 0 : r.quantity) !== 0) continue;
    const c = Yt(l);
    if (!c || c.kind !== n) continue;
    const g = l.quantity ?? ((a = l.system) == null ? void 0 : a.quantity) ?? 0;
    g <= 0 || o.push({
      itemId: l.id,
      quantity: g,
      daysPerUnit: c.daysPerUnit,
      daysUsed: ((u = l.getFlag) == null ? void 0 : u.call(l, d, "daysUsed")) ?? 0
    });
  }
  return o;
}, Se = function() {
  return {
    name: game.i18n.localize("SURVIVAL.HotMeal.EffectName"),
    type: "effect",
    img: "icons/svg/heal.svg",
    system: {
      slug: "hot-meal",
      description: { value: `<p>${game.i18n.localize("SURVIVAL.HotMeal.EffectDesc")}</p>` },
      rules: [],
      traits: { otherTags: [], value: [] },
      level: { value: 0 },
      duration: { value: 1, unit: "days", expiry: "turn-start", sustained: !1 },
      start: { value: 0, initiative: null },
      tokenIcon: { show: !0 },
      unidentified: !1
    }
  };
};
function Jt(t) {
  switch (t) {
    case "pf2e":
      return new Qt();
    default:
      return new Wt();
  }
}
function Xt() {
  var t;
  return Jt(((t = game.system) == null ? void 0 : t.id) ?? "generic");
}
const le = 86400;
let w;
function Zt() {
  var t, e;
  return ((e = (t = game.users) == null ? void 0 : t.activeGM) == null ? void 0 : e.isSelf) === !0;
}
Hooks.on("getSceneControlButtons", (t) => {
  var o;
  const e = (t == null ? void 0 : t.tokens) ?? (Array.isArray(t) ? t.find((s) => s.name === "tokens") : void 0);
  if (!(e != null && e.tools)) return;
  const n = (s) => {
    Array.isArray(e.tools) ? e.tools.push(s) : e.tools[s.name] = s;
  };
  n({
    name: `${d}-hud`,
    title: "SURVIVAL.Hud.Title",
    icon: "fa-solid fa-heart-pulse",
    order: 90,
    button: !0,
    visible: !0,
    onChange: () => he()
  }), (o = game.user) != null && o.isGM && n({
    name: d,
    title: "SURVIVAL.Panel.Title",
    icon: "fa-solid fa-campground",
    order: 91,
    button: !0,
    visible: !0,
    onChange: () => ye()
  });
});
Hooks.once("init", () => {
  Ae(), console.log(`${d} | init — settings registered`);
});
Hooks.once("ready", () => {
  var n, o, s, i, r;
  w = Xt(), pt(w), Nt(w), Gt(), (n = game.user) != null && n.isGM && game.settings.get(d, "supplyDetail") === "ledger" && w.seedSupplies && w.seedSupplies().catch((a) => console.warn(`${d} | seed supplies failed`, a));
  const t = game.modules.get(d);
  t && (t.api = {
    ping: () => "pong",
    computeTick: O,
    defaultTickOptions: ue,
    adapter: w,
    getHeadline: (a) => Ze(w, a),
    readModel: () => Z(w),
    runTick: (a) => K(a, w),
    addSelected: () => me(),
    seedSupplies: () => {
      var a;
      return ((a = w == null ? void 0 : w.seedSupplies) == null ? void 0 : a.call(w)) ?? Promise.resolve();
    },
    openPanel: () => ye(),
    openHud: () => he()
  }), (s = (o = ui.controls) == null ? void 0 : o.render) == null || s.call(o);
  const e = () => {
    Rt(), Ot();
  };
  Hooks.on("updateActor", e), Hooks.on("updateJournalEntry", e), Hooks.on("updateWorldTime", (a, u) => {
    if (!Zt() || !w) return;
    const l = Math.floor((a - u) / le), c = Math.floor(a / le);
    c !== l && K(c, w).then((g) => pe(g)).catch((g) => console.error(`${d} | tick failed`, g));
  }), (r = ui.notifications) == null || r.info(((i = game.i18n) == null ? void 0 : i.localize("SURVIVAL.Loaded")) ?? "Survival module loaded."), console.log(`${d} | ready (system adapter: ${w.systemId})`);
});
Hooks.once("socketlib.ready", () => {
  $t(), console.log(`${d} | socketlib ready`);
});
//# sourceMappingURL=module.js.map
